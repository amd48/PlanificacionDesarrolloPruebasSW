package ppss.ejercicio3;

public enum TipoCoche
{
    TURISMO, DEPORTIVO, CARAVANA
};
