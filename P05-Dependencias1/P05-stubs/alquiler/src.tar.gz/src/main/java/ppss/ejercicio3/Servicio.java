package ppss.ejercicio3;

public class Servicio implements IService
{
    public float consultaPrecio(TipoCoche tipo)
    {
        return 5.0f;
    }
}
