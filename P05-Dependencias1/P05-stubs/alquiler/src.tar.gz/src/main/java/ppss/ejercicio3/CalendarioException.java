package ppss.ejercicio3;

public class CalendarioException extends Throwable
{

}
