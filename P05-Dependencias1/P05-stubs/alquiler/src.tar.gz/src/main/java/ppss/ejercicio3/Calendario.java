package ppss.ejercicio3;

import java.time.LocalDate;

public class Calendario
{
    public boolean es_festivo(LocalDate ld) throws CalendarioException
    {
        return true;
    }
}
