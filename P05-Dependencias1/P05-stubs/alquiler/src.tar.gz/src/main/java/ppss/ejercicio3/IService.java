package ppss.ejercicio3;

public interface IService
{
     public float consultaPrecio(TipoCoche tipo);
}
