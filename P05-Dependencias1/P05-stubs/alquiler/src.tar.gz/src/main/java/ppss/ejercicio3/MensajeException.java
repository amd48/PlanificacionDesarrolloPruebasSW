package ppss.ejercicio3;

public class MensajeException extends Exception
{

    public MensajeException(String observaciones)
    {
        super(observaciones);
    }
}

