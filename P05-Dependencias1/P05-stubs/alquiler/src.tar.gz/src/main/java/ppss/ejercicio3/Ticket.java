package ppss.ejercicio3;

public class Ticket
{
    private float precio_final;


    public float getPrecio_final() { return precio_final; }
    public void setPrecio_final(float pc) { precio_final = pc; }


}
